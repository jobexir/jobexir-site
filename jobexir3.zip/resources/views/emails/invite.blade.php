Hi my friend,
<br>
I want to invite you to join me on <a href="http://jobexir.com"> JobExir </a>
Click on the below button to join me on <a href="http://jobexir.com"> JobExir </a>!
<a href="http://jobexir.com/auth/register/" class="btn btn-info">
    Join me!
</a>