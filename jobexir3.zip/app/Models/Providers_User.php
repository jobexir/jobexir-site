<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Providers_User extends Model
{
    protected $table='providers_users';
}
